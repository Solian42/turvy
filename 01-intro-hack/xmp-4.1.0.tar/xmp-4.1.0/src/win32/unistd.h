#ifndef _XMP_WIN32_UNISTD_H
#define _XMP_WIN32_UNISTD_H

#include <io.h>

void usleep(long usec);

#endif
